<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($data['title']); ?></title>
    <link rel="shortcut icon" type="image/png" href="../assets/images/logos/favicon.png" />
    <link rel="stylesheet" href="/assets/css/styles.min.css" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
    <!--  Body Wrapper -->
    <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed">
        <!-- Sidebar Start -->
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div>
                <div class="brand-logo d-flex align-items-center justify-content-between">
                    <a href="./index.html" class="text-nowrap logo-img">
                        <h2
                            style="font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;">
                            Bloomy Admin</h2>
                    </a>
                    <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
                        <i class="ti ti-x fs-8"></i>
                    </div>
                </div>
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav scroll-sidebar" data-simplebar="">
                    <ul id="sidebarnav">
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Home</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="<?php echo e(route('dashboard.bloomy')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-layout-dashboard"></i>
                                </span>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Menus</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="<?php echo e(route('mUser.bloomy')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-article"></i>
                                </span>
                                <span class="hide-menu">Admin</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="#" aria-expanded="false">
                                <span>
                                    <i class="ti ti-alert-circle"></i>
                                </span>
                                <span class="hide-menu">Pelanggan</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="<?php echo e(route('mWisata.bloomy')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-cards"></i>
                                </span>
                                <span class="hide-menu">Wisata</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="<?php echo e(route('mUMKM.bloomy')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-file-description"></i>
                                </span>
                                <span class="hide-menu">UMKM</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="<?php echo e(route('mKuliner.bloomy')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-menu"></i>
                                </span>
                                <span class="hide-menu">Kuliner</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="<?php echo e(route('mBlog.bloomy')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-typography"></i>
                                </span>
                                <span class="hide-menu">Blog / Artikel</span>
                            </a>
                        </li>
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Report / Transaksi</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="#" aria-expanded="false">
                                <span>
                                    <i class="ti ti-dots"></i>
                                </span>
                                <span class="hide-menu">Transaksi</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="#" aria-expanded="false">
                                <span>
                                    <i class="ti ti-report"></i>
                                </span>
                                <span class="hide-menu">Laporan</span>
                            </a>
                        </li>
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">EXTRA</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="#" aria-expanded="false">
                                <span>
                                    <i class="ti ti-mood-happy"></i>
                                </span>
                                <span class="hide-menu">Kalkulasi</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!--  Sidebar End -->
        <!--  Main wrapper -->
        <div class="body-wrapper">
            <!--  Header Start -->
            <header class="app-header">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <ul class="navbar-nav">
                        <li class="nav-item d-block d-xl-none">
                            <a class="nav-link sidebartoggler nav-icon-hover" id="headerCollapse"
                                href="javascript:void(0)">
                                <i class="ti ti-menu-2"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-icon-hover" href="javascript:void(0)">
                                <i class="ti ti-bell-ringing"></i>
                                <div class="notification bg-primary rounded-circle"></div>
                                <label style="font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif">
                                    Selamat Datang
                                </label>
                                <label style="font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif">
                                    : <?php echo e($user->nama_lengkap); ?>

                                </label>
                            </a>
                        </li>
                    </ul>
                    <div class="navbar-collapse justify-content-end px-0" id="navbarNav">
                        <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-end">
                            <li class="nav-item dropdown">
                                <a class="nav-link nav-icon-hover" href="javascript:void(0)" id="drop2"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <img src="<?php echo e(Storage::url('admin/fotoRegistrasi/' . $user->foto)); ?>"
                                        alt="" width="35" height="35" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-end dropdown-menu-animate-up"
                                    aria-labelledby="drop2">
                                    <div class="message-body">
                                        <a href="javascript:void(0)"
                                            class="d-flex align-items-center gap-2 dropdown-item">
                                            <i class="ti ti-user fs-6"></i>
                                            <p class="mb-0 fs-3">My Profile</p><br>
                                        </a>
                                        <a href="javascript:void(0)"
                                            class="d-flex align-items-center gap-2 dropdown-item">
                                            <i class="ti ti-user fs-6"></i>
                                            <p class="mb-0 fs-3"><?php echo e($user->email); ?></p>
                                        </a>
                                        <a href="#" id="logoutBtn"
                                            class="btn btn-outline-primary mx-3 mt-2 d-block">Logout
                                        </a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                        </ul>
                    </div>
                </nav>
            </header>
            <!--  Header End -->
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title fw-semibold mb-4">
                            <a href="<?php echo e(route('mBlog.bloomy')); ?>">
                                <button class="btn btn-sm btn-danger">Kembali</button>
                            </a>
                        </h5>
                        <div class="container-fluid">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title fw-semibold mb-4">
                                        Menu Admin - Edit Blog Wisata
                                    </h5>
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="editForm" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="mb-3">
                                                    <label for="kategori" class="form-label">Nama Wisata</label>
                                                    <select class="form-control" id="kategori" name="id_wisata"
                                                        required>
                                                        <option value="<?php echo e($data['blog']->wisata->id_wisata); ?>">
                                                            <?php echo e($data['blog']->wisata->nama_wisata); ?></option>
                                                        <?php $__currentLoopData = $wisataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wisataBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($wisataBlog->id_wisata); ?>">
                                                                <?php echo e($wisataBlog->nama_wisata); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="nama_penulis" class="form-label">Nama Penulis</label>
                                                    <input type="text" class="form-control" id="nama_penulis"
                                                        name="nama_penulis" value="<?php echo e($data['blog']->nama_penulis); ?>"
                                                        required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="artikel" class="form-label">Artikel / Blog</label>
                                                    <textarea class="form-control" id="artikel" name="artikel" required><?php echo e($data['blog']->artikel); ?></textarea>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="foto" class="form-label">Upload Foto</label>
                                                    <input type="file" class="form-control" id="foto"
                                                        name="foto_blog">
                                                    <div id="foto-info" style="margin-top: 10px;">
                                                        <p>File sebelumnya: <span
                                                                id="existing-foto-name"><?php echo e($data['blog']->foto_blog); ?></span>
                                                        </p>
                                                    </div>
                                                    <img id="previewFoto"
                                                        src="/storage/admin/fotoBlog/<?php echo e($data['blog']->foto_blog); ?>"
                                                        alt="Preview Foto" width="100"
                                                        style="margin-top: 10px; display: <?php echo e($data['blog']->foto_blog ? 'block' : 'none'); ?>;">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="tgl_input" class="form-label">Tanggal Input</label>
                                                    <input type="date" class="form-control" id="tgl_input"
                                                        name="tgl_input" value="<?php echo e($data['blog']->tgl_input); ?>"
                                                        required>
                                                </div>
                                                <button type="submit" class="btn btn-primary">Simpan
                                                    Perubahan</button>
                                            </form>

                                            <div id="responseMessage" class="mt-3"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <script src="/assets/libs/jquery/dist/jquery.min.js"></script>
            <script src="/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
            <script src="/assets/js/sidebarmenu.js"></script>
            <script src="/assets/js/app.min.js"></script>
            
            <script src="/assets/libs/simplebar/dist/simplebar.js"></script>
            
            
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false" async
                defer></script>

            <script>
                $(document).ready(function() {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });

                    $('#editForm').submit(function(e) {
                        e.preventDefault();

                        var formData = new FormData(this);

                        $.ajax({
                            url: "<?php echo e(route('updateWisataBlog.bloomy', $data['blog']->id_blog)); ?>",
                            type: 'POST',
                            data: formData,
                            contentType: false,
                            processData: false,
                            success: function(response) {
                                if (response.success) {
                                    alert('Blog berhasil diperbarui!');
                                    window.location.href = "<?php echo e(route('mBlog.bloomy')); ?>";
                                } else {
                                    console.error(response.message);
                                    alert('Gagal memperbarui Blog.');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error(xhr.responseText);
                                var errorMessage = "Terjadi kesalahan saat memproses permintaan Anda.";
                                if (xhr.status === 422) {
                                    errorMessage = "Terjadi kesalahan validasi.";
                                } else if (xhr.status === 500) {
                                    errorMessage =
                                        "Terjadi kesalahan internal server. Silakan coba lagi nanti.";
                                }
                                alert(errorMessage);
                            }
                        });
                    });

                    $('#foto').change(function() {
                        var input = this;
                        if (input.files && input.files[0]) {
                            var reader = new FileReader();
                            reader.onload = function(e) {
                                $('#previewFoto').attr('src', e.target.result).show();
                            }
                            reader.readAsDataURL(input.files[0]);
                        }
                    });
                });
            </script>
</body>

</html>
<?php /**PATH C:\Users\JON\Documents\GitHub\BloomyApp\BloomyApp\AppBloomy\resources\views/admin/menus/edit/mWisataBlogEdit.blade.php ENDPATH**/ ?>