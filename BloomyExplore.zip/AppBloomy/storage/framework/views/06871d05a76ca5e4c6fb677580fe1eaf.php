<?php echo $__env->make('admin.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.theme.navProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>Statistika Komputasi</h1>

<div class="card">
    <div class="card-body">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.bloomy')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Data Kepuasan Penggunaan Website</li>
            </ol>
        </nav>
        
        <button class="btn btn-sm btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#openChoice">Export to
            CSV</button>
        <div class="table-responsive">
            <table id="laporanTable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID Review</th>
                        <th>Email</th>
                        <th>Nama</th>
                        <th>Tujuan</th>
                        <th>NP1</th>
                        <th>NP2</th>
                        <th>NP3</th>
                        <th>NP4</th>
                        <th>NP5</th>
                        <th>NP6</th>
                        <th>NP7</th>
                        <th>NP8</th>
                        <th>NP9</th>
                        <th>NP10</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $laporansPaginate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($laporan->id_review); ?></td>
                            <td><?php echo e($laporan->email); ?></td>
                            <td><?php echo e($laporan->nama_lengkap); ?></td>
                            <td><?php echo e($laporan->tujuan); ?></td>
                            <td><?php echo e($laporan->np1); ?></td>
                            <td><?php echo e($laporan->np2); ?></td>
                            <td><?php echo e($laporan->np3); ?></td>
                            <td><?php echo e($laporan->np4); ?></td>
                            <td><?php echo e($laporan->np5); ?></td>
                            <td><?php echo e($laporan->np6); ?></td>
                            <td><?php echo e($laporan->np7); ?></td>
                            <td><?php echo e($laporan->np8); ?></td>
                            <td><?php echo e($laporan->np9); ?></td>
                            <td><?php echo e($laporan->np10); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
            <table id="laporanTableAllData" class="table table-bordered" hidden>
                <thead>
                    <tr>
                        <th>ID Review</th>
                        <th>Email</th>
                        <th>Nama</th>
                        <th>Tujuan</th>
                        <th>NP1</th>
                        <th>NP2</th>
                        <th>NP3</th>
                        <th>NP4</th>
                        <th>NP5</th>
                        <th>NP6</th>
                        <th>NP7</th>
                        <th>NP8</th>
                        <th>NP9</th>
                        <th>NP10</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($laporan->id_review); ?></td>
                            <td><?php echo e($laporan->email); ?></td>
                            <td><?php echo e($laporan->nama_lengkap); ?></td>
                            <td><?php echo e($laporan->tujuan); ?></td>
                            <td><?php echo e($laporan->np1); ?></td>
                            <td><?php echo e($laporan->np2); ?></td>
                            <td><?php echo e($laporan->np3); ?></td>
                            <td><?php echo e($laporan->np4); ?></td>
                            <td><?php echo e($laporan->np5); ?></td>
                            <td><?php echo e($laporan->np6); ?></td>
                            <td><?php echo e($laporan->np7); ?></td>
                            <td><?php echo e($laporan->np8); ?></td>
                            <td><?php echo e($laporan->np9); ?></td>
                            <td><?php echo e($laporan->np10); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
            <nav aria-label="Page navigation example">
                <ul class="pagination justify-content-end">
                    <?php if($laporansPaginate->onFirstPage()): ?>
                        <li class="page-item disabled">
                            <a class="page-link" href="#" tabindex="-1">Previous</a>
                        </li>
                    <?php else: ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($laporansPaginate->previousPageUrl()); ?>"
                                tabindex="-1">Previous</a>
                        </li>
                    <?php endif; ?>

                    <?php $__currentLoopData = $laporansPaginate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li
                            class="page-item <?php echo e($laporansPaginate->currentPage() == $loop->iteration ? 'active' : ''); ?>">
                            <a class="page-link"
                                href="<?php echo e($laporansPaginate->url($loop->iteration)); ?>"><?php echo e($loop->iteration); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($laporansPaginate->hasMorePages()): ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($laporansPaginate->nextPageUrl()); ?>">Next</a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <a class="page-link" href="#">Next</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="openChoice" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn btn-sm btn-outline-danger" data-bs-dismiss="modal">X</button>
            </div>
            <div class="modal-body mx-auto">
                <button class="btn btn-sm btn-primary" onclick="exportToCSV_AllData()">Export (All Data)</button>
                <button class="btn btn-sm btn-info" onclick="exportToCSV()">Export (5 Data)</button>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<script>
    function exportToCSV() {
        const rows = document.querySelectorAll("#laporanTable tbody tr");
        const csvContent = [];

        // Header
        const header = Array.from(document.querySelectorAll("#laporanTable thead th"))
            .map(th => th.innerText.trim());
        csvContent.push(header.join(','));

        rows.forEach(row => {
            const rowData = Array.from(row.querySelectorAll("td")).map(td => td.innerText.trim());
            csvContent.push(rowData.join(','));
        });

        const csvData = csvContent.join('\n');

        const link = document.createElement('a');
        link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvData));
        link.setAttribute('download', 'laporan.csv');
        link.style.display = 'none';
        document.body.appendChild(link);

        link.click();
        document.body.removeChild(link);
    }
</script>

<script>
    function exportToCSV_AllData() {
        const rows = document.querySelectorAll("#laporanTableAllData tbody tr");
        const csvContent = [];

        // Header
        const header = Array.from(document.querySelectorAll("#laporanTable thead th"))
            .map(th => th.innerText.trim());
        csvContent.push(header.join(','));

        rows.forEach(row => {
            const rowData = Array.from(row.querySelectorAll("td")).map(td => td.innerText.trim());
            csvContent.push(rowData.join(','));
        });

        const csvData = csvContent.join('\n');

        const link = document.createElement('a');
        link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvData));
        link.setAttribute('download', 'laporan.csv');
        link.style.display = 'none';
        document.body.appendChild(link);

        link.click();
        document.body.removeChild(link);
    }
</script>

</body>

</html>
<?php /**PATH C:\Users\JON\Documents\GitHub\BloomyApp-BE\BloomyApp\AppBloomy\resources\views/admin/menus/mKalkulasi.blade.php ENDPATH**/ ?>