<?php echo $__env->make('admin.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.theme.navProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <div class="alert alert-warning" role="alert">
                <h4 class="alert-heading">Coming Soon!</h4>
                <p>Fitur masih dibuat dan rancang sesuai dengan data aktual dengan kategori pada jenis usaha yang kami
                    sediakan.</p>
                <hr>
                <p class="mb-0">Kami harap anda semua harap menunggu untuk menantikan rilisnya fitur berikut terima
                    aksih.</p>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>


</body>

</html>
<?php /**PATH C:\Users\JON\Documents\GitHub\BloomyApp\BloomyApp\AppBloomy\resources\views/admin/menus/mLaporanKategoriWisata.blade.php ENDPATH**/ ?>