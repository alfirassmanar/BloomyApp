<?php echo $__env->make('admin.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.theme.navProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('mPekerja.bloomy')); ?>">Home</a>
                    <li class="breadcrumb-item active">Tambah Data</li>
                    </li>
                </ol>
            </nav>
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title fw-semibold mb-4">
                            Pekerja - Tambah Data
                        </h5>
                        <div class="card">
                            <div class="card-body">
                                <form id="addForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="id_user" class="form-label">Nama Pekerja</label>
                                        <select class="form-control" name="id_user">
                                            <option>Pilih Pekerja</option>
                                            <?php $__currentLoopData = $data['getUser']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gtUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($gtUser->id_user); ?>"
                                                    <?php echo e($data['pekerjaTambah']->id_user == $gtUser->id_user ? 'selected' : ''); ?>>
                                                    <?php echo e($gtUser->nama_lengkap); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="id_wisata" class="form-label">Tour Guide</label>
                                        <select class="form-control" name="id_wisata">
                                            <option>Pilih Memandu Wisata</option>
                                            <?php $__currentLoopData = $data['getWisata']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gtWisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($gtWisata->id_wisata); ?>"
                                                    <?php echo e($data['pekerjaTambah']->id_wisata == $gtWisata->id_wisata ? 'selected' : ''); ?>>
                                                    <?php echo e($gtWisata->nama_wisata); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="alamat_pekerja" class="form-label">Alamat</label>
                                        <input type="text" class="form-control" id="alamat_pekerja"
                                            name="alamat_pekerja" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="no_hp" class="form-label">Nomor Handphone</label>
                                        <input type="number" class="form-control" id="no_hp" name="no_hp"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="berkas" class="form-label">Berkas Pekerja</label>
                                        <input type="file" class="form-control" id="berkas" name="berkas"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="berkas" class="form-label">Upload Foto
                                            Formal</label>
                                        <input type="file" class="form-control" id="foto_pekerja" name="foto_pekerja"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tgl_masuk" class="form-label">Tanggal Masuk</label>
                                        <input type="date" class="form-control" id="tgl_masuk" name="tgl_masuk"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tgl_keluar" class="form-label">Tanggal Keluar</label>
                                        <input type="date" class="form-control" id="tgl_keluar" name="tgl_keluar">
                                    </div>
                                    <button type="submit" class="btn btn-sm btn-primary">Tambah</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
</div>
<?php echo $__env->make('admin.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script>
    $(document).ready(function() {
        $('#addForm').on('submit', function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            $.ajax({
                url: "<?php echo e(route('prosesTambahPekerja.bloomy')); ?>",
                type: 'POST',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    console.log(data);
                    alert('Pekerja berhasil ditambahkan!');
                    window.location.href = "<?php echo e(route('mPekerja.bloomy')); ?>";
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('Terjadi kesalahan saat menambahkan Pekerja: ' + xhr
                        .responseText);
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#logoutBtn').on('click', function(e) {
            e.preventDefault();
            $.ajax({
                url: "<?php echo e(route('prosesLogout.admin.bloomy')); ?>",
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        window.location.href = "<?php echo e(route('login.admin.bloomy')); ?>";
                    } else {
                        alert('Failed to logout.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('An error occurred while processing your request.');
                }
            });
        });
    });
</script>
</body>

</html>
<?php /**PATH C:\Users\JON\Documents\GitHub\BloomyApp\BloomyApp\AppBloomy\resources\views/admin/menus/add/mPekerjaTambah.blade.php ENDPATH**/ ?>