<?php echo $__env->make('admin.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.theme.navProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('mTour.bloomy')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('mTourTambah.bloomy')); ?>">Tambah Data</a></li>
                    <li class="breadcrumb-item active">Edit Data</li>
                </ol>
            </nav>
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title fw-semibold mb-4">
                            Tour - Edit Data
                        </h5>
                        <div class="card">
                            <div class="card-body">
                                <form id="editForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id_tour" value="<?php echo e($data['tourEdit']->id_tour); ?>">
                                    <div class="mb-3">
                                        <label for="nama_tour" class="form-label">Nama Tour</label>
                                        <input type="text" class="form-control" id="nama_tour" name="nama_tour"
                                            value="<?php echo e($data['tourEdit']->nama_tour); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="start_date" class="form-label">Tanggal Mulai</label>
                                        <input type="datetime-local" class="form-control" id="start_date"
                                            name="tgl_mulai" value="<?php echo e($data['tourEdit']->tgl_mulai); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="end_date" class="form-label">Tanggal
                                            Selesai</label>
                                        <input type="datetime-local" class="form-control" id="end_date"
                                            name="tgl_selesai" value="<?php echo e($data['tourEdit']->tgl_selesai); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="lama_tour" class="form-label">Lama Tour</label>
                                        <input type="text" class="form-control" id="lama_tour" name="lama_tour"
                                            value="<?php echo e($data['tourEdit']->lama_tour); ?>" required readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="id_wisata" class="form-label">Jalur/Lokasi
                                            Wisata</label>
                                        <select class="form-control" id="id_wisata" required>
                                            <?php $__currentLoopData = $getWisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gtwisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($gtwisata->id_wisata); ?>">
                                                    <?php echo e($gtwisata->nama_wisata); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <p>Wisata:
                                            <?php $__currentLoopData = $namaWisataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($wisata->nama_wisata); ?><?php if(!$loop->last): ?>
                                                    ,
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </p>
                                        <button type="button" id="pilihWisata"
                                            class="btn btn-primary mt-2">Pilih</button>
                                        <input type="hidden" id="id_wisata_selected" name="id_wisata">
                                    </div>

                                    <div class="selected-wisata-list mt-3">
                                        <!-- Tempat untuk menampilkan wisata yang dipilih -->
                                    </div>
                                    <div class="mb-3">
                                        <label for="fasilitas_penginapan" class="form-label">Pilih
                                            Penginapan</label>
                                        <select class="form-control" id="fasilitas_penginapan"
                                            name="fasilitas_penginapan" required>
                                            <option value="">Pilih Penginapan</option>
                                        </select>
                                        <p>Penginapan : <?php echo e($data['tourEdit']->fasilitas_penginapan); ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label for="fasilitas_konsumsi" class="form-label">Fasilitas
                                            Komsumsi</label>
                                        <input type="text" class="form-control" id="fasilitas_konsumsi"
                                            name="fasilitas_konsumsi"
                                            value="<?php echo e($data['tourEdit']->fasilitas_konsumsi); ?>" required>
                                    </div>
                                    <button type="submit" class="btn btn-sm btn-primary">Simpan
                                        Perubahan</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
</div>

<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Ajax request to get tour data
        $.ajax({
            url: "<?php echo e(route('prosesEditTour.bloomy', $data['tourEdit']->id_tour)); ?>",
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    var tour = response.tour;
                    $('#nama_tour').val(tour.nama_tour);
                    $('#start_date').val(formatDateTime(tour.tgl_mulai));
                    $('#end_date').val(formatDateTime(tour.tgl_selesai));
                    $('#id_wisata').val(tour.id_wisata);
                    $('#fasilitas_penginapan').val(tour.fasilitas_penginapan);
                    $('#fasilitas_konsumsi').val(tour.fasilitas_konsumsi);

                    // Calculate and display tour duration
                    calculateTourDuration();
                } else {
                    console.error(response.message);
                    alert('Gagal mengambil data tour.');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                alert('Terjadi kesalahan saat mengambil data tour.');
            }
        });

        // Submit form via Ajax
        $('#editForm').submit(function(e) {
            e.preventDefault();

            var formData = new FormData(this);

            $.ajax({
                url: "<?php echo e(route('updateTour.bloomy', $data['tourEdit']->id_tour)); ?>",
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.success) {
                        alert('Tour berhasil diperbarui!');
                        window.location.href = "<?php echo e(route('mTour.bloomy')); ?>";
                    } else {
                        console.error(response.message);
                        alert('Gagal memperbarui Tour.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('Terjadi kesalahan saat memproses permintaan Anda.');
                }
            });

        });

        // Function to format datetime from server format to input format
        function formatDateTime(datetime) {
            var date = new Date(datetime);
            var formattedDate = date.toISOString().slice(0, 16);
            return formattedDate;
        }

        // Function to calculate tour duration
        function calculateTourDuration() {
            var startDate = new Date($('#start_date').val());
            var endDate = new Date($('#end_date').val());

            if (startDate && endDate && endDate > startDate) {
                // Calculate time difference in milliseconds
                var timeDifference = endDate - startDate;

                // Calculate number of days and nights
                var days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
                var nights = days - 1;

                // Display result
                $('#lama_tour').val(days + ' hari ' + nights + ' malam');
            } else {
                $('#lama_tour').val('');
            }
        }

        // Event listener for start date change
        $('#start_date').change(calculateTourDuration);

        // Event listener for end date change
        $('#end_date').change(calculateTourDuration);
    });
</script>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        const selectWisata = document.getElementById('id_wisata');
        const buttonPilih = document.getElementById('pilihWisata');
        const inputHidden = document.getElementById('id_wisata_selected');
        const selectedList = document.querySelector('.selected-wisata-list');

        let selectedWisata = [];

        buttonPilih.addEventListener('click', function() {
            const selectedOption = selectWisata.options[selectWisata.selectedIndex];
            if (selectedOption && !selectedWisata.includes(selectedOption.value)) {
                selectedWisata.push(selectedOption.value);
                updateSelectedList();
                updateHiddenInput();
            }
        });

        function updateSelectedList() {
            selectedList.innerHTML = '';
            selectedWisata.forEach(function(wisataId) {
                const wisataText = selectWisata.querySelector(`option[value="${wisataId}"]`).text;
                const listItem = document.createElement('div');
                listItem.textContent = wisataText;
                selectedList.appendChild(listItem);
            });
        }

        function updateHiddenInput() {
            inputHidden.value = selectedWisata.join(',');
        }
    });
</script>

<script>
    function calculateTourDuration() {
        const startDate = new Date(document.getElementById('start_date').value);
        const endDate = new Date(document.getElementById('end_date').value);

        if (startDate && endDate && endDate > startDate) {
            // Menghitung selisih dalam milidetik
            const timeDifference = endDate - startDate;

            // Menghitung jumlah hari dan malam
            const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
            const nights = days - 1;

            // Menampilkan hasil
            document.getElementById('lama_tour').value = `${days} hari ${nights} malam`;
        } else {
            document.getElementById('lama_tour').value = '';
        }
    }

    document.getElementById('start_date').addEventListener('change', calculateTourDuration);
    document.getElementById('end_date').addEventListener('change', calculateTourDuration);
</script>

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        axios.post('/json/dataPenginapan')
            .then(function(response) {

                const penginapanData = response.data;

                const dropdown = document.getElementById('fasilitas_penginapan');

                penginapanData.forEach(function(penginapan) {
                    const option = document.createElement('option');
                    option.value = penginapan.nama;
                    option.textContent = penginapan
                        .nama;
                    dropdown.appendChild(option);
                });
            })
            .catch(function(error) {
                console.error('Error fetching JSON:', error);
            });
    });
</script>


<script>
    $(document).ready(function() {
        $('#logoutBtn').on('click', function(e) {
            e.preventDefault();
            $.ajax({
                url: "<?php echo e(route('prosesLogout.admin.bloomy')); ?>",
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        window.location.href = "<?php echo e(route('login.admin.bloomy')); ?>";
                    } else {
                        alert('Failed to logout.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('An error occurred while processing your request.');
                }
            });
        });
    });
</script>
</body>

</html>
<?php /**PATH C:\Users\JON\Documents\GitHub\BloomyApp\BloomyApp\AppBloomy\resources\views/admin/menus/edit/mTourEdit.blade.php ENDPATH**/ ?>