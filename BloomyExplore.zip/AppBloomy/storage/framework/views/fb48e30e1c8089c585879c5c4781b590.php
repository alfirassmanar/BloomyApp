<?php echo $__env->make('admin.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.theme.navProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('mPekerja.bloomy')); ?>">Home</a>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('mPekerjaTambah.bloomy')); ?>">Tambah Data</a>
                    <li class="breadcrumb-item active">Edit Data</li>
                    </li>
                </ol>
            </nav>
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title fw-semibold mb-4">
                            Pekerja - Edit Data
                        </h5>
                        <div class="card">
                            <div class="card-body">
                                <form id="editForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="id_user" class="form-label">Nama Pekerja</label>
                                        <select class="form-control" name="id_user">
                                            <option>Pilih Pekerja</option>
                                            <?php $__currentLoopData = $data['getUser']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gtUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($gtUser->id_user); ?>"
                                                    <?php echo e($data['pekerjaEdit']->id_user == $gtUser->id_user ? 'selected' : ''); ?>>
                                                    <?php echo e($gtUser->nama_lengkap); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="id_wisata" class="form-label">Tour Guide</label>
                                        <select class="form-control" name="id_wisata">
                                            <option>Pilih Memandu Wisata</option>
                                            <?php $__currentLoopData = $data['getWisata']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gtWisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($gtWisata->id_wisata); ?>"
                                                    <?php echo e($data['pekerjaEdit']->id_wisata == $gtWisata->id_wisata ? 'selected' : ''); ?>>
                                                    <?php echo e($gtWisata->nama_wisata); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="alamat_pekerja" class="form-label">Alamat</label>
                                        <input type="text" class="form-control" id="alamat_pekerja"
                                            name="alamat_pekerja" value="<?php echo e($data['pekerjaEdit']->alamat_pekerja); ?>"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="no_hp" class="form-label">Nomor Handphone</label>
                                        <input type="number" class="form-control" id="no_hp" name="no_hp"
                                            value="<?php echo e($data['pekerjaEdit']->no_hp); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="berkas" class="form-label">Berkas Pekerja</label>
                                        <input type="file" class="form-control" id="berkas" name="berkas">
                                        <p>Berkas Sebelumnya: <?php echo e($data['pekerjaEdit']->berkas); ?></p>
                                        <iframe id="previewBerkas"
                                            src="/storage/admin/fotoPekerja/berkasPekerja/<?php echo e($data['pekerjaEdit']->berkas); ?>"
                                            width="100%" height="200"
                                            style="display: <?php echo e($data['pekerjaEdit']->berkas ? 'block' : 'none'); ?>;"></iframe>
                                    </div>
                                    <div class="mb-3">
                                        <label for="foto_pekerja" class="form-label">Upload Foto</label>
                                        <input type="file" class="form-control" id="foto_pekerja"
                                            name="foto_pekerja">
                                        <div id="foto-info" style="margin-top: 10px;">
                                            <p>File sebelumnya: <span
                                                    id="existing-foto-name"><?php echo e($data['pekerjaEdit']->foto_pekerja); ?></span>
                                            </p>
                                        </div>
                                        <img id="previewFoto"
                                            src="/storage/admin/fotoPekerja/<?php echo e($data['pekerjaEdit']->foto_pekerja); ?>"
                                            alt="Preview Foto" width="100"
                                            style="margin-top: 10px; display: <?php echo e($data['pekerjaEdit']->foto_pekerja ? 'block' : 'none'); ?>;">
                                    </div>
                                    <div class="mb-3">
                                        <label for="tgl_masuk" class="form-label">Tanggal Masuk</label>
                                        <input type="date" class="form-control" id="tgl_masuk" name="tgl_masuk"
                                            value="<?php echo e($data['pekerjaEdit']->tgl_masuk); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tgl_keluar" class="form-label">Tanggal Keluar</label>
                                        <input type="date" class="form-control" id="tgl_keluar"
                                            value="<?php echo e($data['pekerjaEdit']->tgl_keluar); ?>" name="tgl_keluar">
                                    </div>
                                    <button type="submit" class="btn btn-sm btn-primary">Simpan</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>

<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: "<?php echo e(route('prosesEditPekerja.bloomy', $data['id_pekerja'])); ?>",
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    var pekerja = response.pekerjaEdit;
                    $('#id_user').val(pekerja.id_user);
                    $('#id_wisata').val(pekerja.id_wisata);
                    $('#alamat_pekerja').val(pekerja.alamat_pekerja);
                    $('#no_hp').val(pekerja.no_hp);
                    $('#tgl_masuk').val(pekerja.tgl_masuk);
                    $('#tgl_keluar').val(pekerja.tgl_keluar);

                    if (pekerja.foto_pekerja) {
                        $('#previewFoto').attr('src', '/storage/admin/fotoPekerja/' + pekerja
                            .foto_pekerja).show();
                        $('#existing-foto-name').text(pekerja.foto_pekerja);
                    }

                    if (pekerja.berkas) {
                        $('#previewBerkas').attr('src',
                                '/storage/admin/fotoPekerja/berkasPekerja/' +
                                pekerja.berkas)
                            .show();
                    }
                } else {
                    console.error(response.message);
                    alert('Gagal mengambil data pekerja.');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                alert('Terjadi kesalahan saat mengambil data pekerja.');
            }
        });

        $('#editForm').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            $.ajax({
                url: "<?php echo e(route('updatePekerja.bloomy', $data['id_pekerja'])); ?>",
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.success) {
                        alert('Pekerja berhasil diperbarui!');
                        window.location.href = "<?php echo e(route('mPekerja.bloomy')); ?>";
                    } else {
                        console.error(response.message);
                        alert('Gagal memperbarui pekerja.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    var errorMessage = "Terjadi kesalahan saat memproses permintaan Anda.";
                    if (xhr.status === 422) {
                        errorMessage =
                            "Terjadi kesalahan validasi. Silakan cek input Anda.";
                    } else if (xhr.status === 500) {
                        errorMessage =
                            "Terjadi kesalahan internal server. Silakan coba lagi nanti.";
                    }
                    alert(errorMessage);
                }
            });
        });

        $('#foto_pekerja').change(function() {
            var input = this;
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#previewFoto').attr('src', e.target.result).show();
                    $('#existing-foto-name').text(input.files[0].name);
                }
                reader.readAsDataURL(input.files[0]);
            }
        });

        $('#berkas').change(function() {
            var input = this;
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#previewBerkas').attr('src', e.target.result).show();
                }
                reader.readAsDataURL(input.files[0]);
            }
        });
    });
</script>


<script>
    $(document).ready(function() {
        $('#logoutBtn').on('click', function(e) {
            e.preventDefault();
            $.ajax({
                url: "<?php echo e(route('prosesLogout.admin.bloomy')); ?>",
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        window.location.href = "<?php echo e(route('login.admin.bloomy')); ?>";
                    } else {
                        alert('Failed to logout.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('An error occurred while processing your request.');
                }
            });
        });
    });
</script>
</body>

</html>
<?php /**PATH C:\Users\JON\Documents\GitHub\BloomyApp\BloomyApp\AppBloomy\resources\views/admin/menus/edit/mPekerjaEdit.blade.php ENDPATH**/ ?>