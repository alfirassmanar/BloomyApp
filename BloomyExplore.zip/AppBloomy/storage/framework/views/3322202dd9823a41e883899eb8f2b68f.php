<?php echo $__env->make('admin.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.theme.navProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('mUMKM.bloomy')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Tambah Data</li>
                </ol>
            </nav>
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title fw-semibold mb-4">
                            UMKM - Tambah Data
                        </h5>
                        <div class="card">
                            <div class="card-body">
                                <form id="addForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="nama_umkm" class="form-label">Nama UMKM</label>
                                        <input type="text" class="form-control" id="nama_umkm" name="nama_umkm"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="id_umkm" class="form-label">Kategori</label>
                                        <select class="form-control" id="id_umkm" name="id_umkm" required>
                                            <option value="">Pilih Kategori</option>
                                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kategories->id_kategori); ?>">
                                                    <?php echo e($kategories->kategori); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="keterangan" class="form-label">Keterangan</label>
                                        <input type="text" class="form-control" name="keterangan" id="keterangan">
                                    </div>
                                    <div class="mb-3">
                                        <label for="foto" class="form-label">Upload Foto</label>
                                        <input type="file" class="form-control" id="foto" name="foto_usaha"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tgl_berdiri" class="form-label">Tanggal
                                            Berdiri</label>
                                        <input type="date" class="form-control" id="tgl_berdiri" name="tgl_berdiri"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tgl_input" class="form-label">Tanggal Input ke
                                            Bloomy</label>
                                        <input type="date" class="form-control" id="tgl_input" name="tgl_input"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="generateChooseMaps" class="form-label">Cari Lokasi
                                            Wisata</label>
                                        <div class="mapouter">
                                            <div class="gmap_canvas">
                                                <iframe width="820" height="560" id="gmap_canvas"
                                                    id="iframeklikmaps"
                                                    src="https://maps.google.com/maps?q=Sidoarjo%2C+Jawa+Timur+Indonesia&t=&z=10&ie=UTF8&iwloc=&output=embed"
                                                    frameborder="0" scrolling="no" marginheight="0"
                                                    marginwidth="0"></iframe>
                                                <style>
                                                    .mapouter {
                                                        position: relative;
                                                        text-align: right;
                                                        height: 560px;
                                                        width: 820px;
                                                        margin-bottom: 20px;
                                                    }
                                                </style>
                                                <style>
                                                    .gmap_canvas {
                                                        overflow: hidden;
                                                        background: none !important;
                                                        height: 560px;
                                                        width: 820px;
                                                    }
                                                </style>
                                            </div>
                                        </div>
                                        <input type="text" class="form-control" id="generateChooseMaps"
                                            placeholder="Masukkan alamat atau nama lokasi" name="lokasi" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Simpan
                                        Perubahan</button>
                                </form>

                                <div id="responseMessage" class="mt-3"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>


<script>
    $(document).ready(function() {
        $('#addForm').on('submit', function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            $.ajax({
                url: "<?php echo e(route('prosesTambahUMKM.bloomy')); ?>",
                type: 'POST',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    console.log(data);
                    alert('UMKM berhasil ditambahkan!');
                    window.location.href = "<?php echo e(route('mUMKM.bloomy')); ?>";
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('Terjadi kesalahan saat menambahkan UMKM.');
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#logoutBtn').on('click', function(e) {
            e.preventDefault();
            $.ajax({
                url: "<?php echo e(route('prosesLogout.admin.bloomy')); ?>",
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        window.location.href = "<?php echo e(route('login.admin.bloomy')); ?>";
                    } else {
                        alert('Failed to logout.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('An error occurred while processing your request.');
                }
            });
        });
    });
</script>
</body>

</html>
<?php /**PATH C:\Users\JON\Documents\GitHub\BloomyApp\BloomyApp\AppBloomy\resources\views/admin/menus/add/mUMKMTambah.blade.php ENDPATH**/ ?>