<?php echo $__env->make('admin.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.theme.navProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
</div>

<?php echo $__env->make('admin.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>

</body>

</html>
<?php /**PATH C:\Users\JON\Documents\GitHub\BloomyApp\BloomyApp\AppBloomy\resources\views/admin/menus/mLaporan.blade.php ENDPATH**/ ?>