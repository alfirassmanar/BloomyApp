<?php echo $__env->make('admin.theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('mBlog.bloomy')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Tambah Data</li>
                </ol>
            </nav>
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title fw-semibold mb-4">
                            Blog - Tambah Data
                        </h5>
                        <div class="card">
                            <div class="card-body">
                                <form id="addForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="id_kategori" class="form-label">Kategori</label>
                                        <select class="form-control" id="id_kategori" name="id_kategori" required>
                                            <option value="">Pilih Kategori</option>
                                            <?php $__currentLoopData = $data['kategori']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kategoriBlog->id_kategori); ?>">
                                                    <?php echo e($kategoriBlog->kategori); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="id_wisata" class="form-label">Nama Wisata / UMKM /
                                            Kuliner</label>
                                        <select class="form-control" id="id_wisata" name="id_wisata" required>
                                            <option value="">Pilih Wisata / UMKM / Kuliner</option>
                                            <!-- Opsi akan diisi melalui AJAX -->
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nama_penulis" class="form-label">Nama Penulis</label>
                                        <input type="text" class="form-control" id="nama_penulis" name="nama_penulis"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="artikel" class="form-label">Artikel</label>
                                        <textarea class="form-control" id="artikel" name="artikel" required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="foto_blog" class="form-label">Foto Blog</label>
                                        <input type="file" class="form-control" id="foto_blog" name="foto_blog"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tgl_input" class="form-label">Tanggal Artikel</label>
                                        <input type="date" class="form-control" id="tgl_input" name="tgl_input"
                                            required>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Simpan Artikel</button>
                                </form>

                                <div id="responseMessage" class="mt-3"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
</div>
<?php echo $__env->make('admin.theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script>
    $(document).ready(function() {
        $('#id_kategori').on('change', function() {
            var id_kategori = $(this).val();

            $('#id_wisata').empty();
            $('#id_wisata').append('<option value="">Memuat...</option>');

            $.ajax({
                url: "<?php echo e(route('getUsahaKategori')); ?>",
                type: 'GET',
                data: {
                    id_kategori: id_kategori
                },
                success: function(response) {
                    $('#id_wisata').empty();

                    if (response.length > 0) {
                        $.each(response, function(key, value) {
                            $('#id_wisata').append('<option value="' + value.id +
                                '">' + value.nama + '</option>');
                        });
                    } else {
                        $('#id_wisata').append(
                            '<option value="">Tidak ada usaha tersedia untuk kategori ini</option>'
                        );
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('Terjadi kesalahan saat memuat opsi wisata / UMKM / kuliner.');
                }
            });
        });

        // Handler untuk form submit
        $('#addForm').on('submit', function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            $.ajax({
                url: "<?php echo e(route('prosesTambahBlog.bloomy')); ?>",
                type: 'POST',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    console.log(response);
                    alert('Artikel berhasil ditambahkan!');
                    window.location.href = "<?php echo e(route('mBlog.bloomy')); ?>";
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('Terjadi kesalahan saat menambahkan artikel.');
                }
            });
        });
    });
</script>


<script>
    $(document).ready(function() {
        $('#logoutBtn').on('click', function(e) {
            e.preventDefault();
            $.ajax({
                url: "<?php echo e(route('prosesLogout.admin.bloomy')); ?>",
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        window.location.href = "<?php echo e(route('login.admin.bloomy')); ?>";
                    } else {
                        alert('Failed to logout.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('An error occurred while processing your request.');
                }
            });
        });
    });
</script>
</body>

</html>
<?php /**PATH C:\Users\JON\Documents\GitHub\BloomyApp\BloomyApp\AppBloomy\resources\views/admin/menus/add/mBlogTambah.blade.php ENDPATH**/ ?>