<?php
return [
    'auth.admin' => \App\Http\Middleware\Check_LoginAdmin::class,
];
