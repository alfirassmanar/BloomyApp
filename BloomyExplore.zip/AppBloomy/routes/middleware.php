<?php
return [
    // Middleware lainnya
    'admin' => \App\Http\Middleware\Check_LoginAdmin::class,
];
