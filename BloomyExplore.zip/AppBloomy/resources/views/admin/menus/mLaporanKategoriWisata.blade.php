@include('admin.theme.header')
@include('admin.theme.navProfile')

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <div class="alert alert-warning" role="alert">
                <h4 class="alert-heading">Coming Soon!</h4>
                <p>Fitur masih dibuat dan rancang sesuai dengan data aktual dengan kategori pada jenis usaha yang kami
                    sediakan.</p>
                <hr>
                <p class="mb-0">Kami harap anda semua harap menunggu untuk menantikan rilisnya fitur berikut terima
                    aksih.</p>
            </div>
        </div>
    </div>
</div>

@include('admin.theme.footer')
</div>
</div>


</body>

</html>
